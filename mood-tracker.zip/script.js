const ctx = document.getElementById('moodChart').getContext('2d');
let moodData = JSON.parse(localStorage.getItem('moodData')) || [];

const chart = new Chart(ctx, {
  type: 'line',
  data: {
    labels: moodData.map(entry => entry.date),
    datasets: [{
      label: 'Mood Over Time',
      data: moodData.map(entry => entry.moodScore),
      borderColor: '#4caf50',
      tension: 0.3,
      fill: false
    }]
  },
  options: {
    responsive: true
  }
});

function logMood() {
  const mood = document.getElementById('mood').value;
  const date = new Date().toLocaleDateString();
  const moodScore = {
    Happy: 5,
    Excited: 4,
    Anxious: 3,
    Sad: 2,
    Angry: 1
  }[mood];

  moodData.push({ date, moodScore });
  localStorage.setItem('moodData', JSON.stringify(moodData));

  chart.data.labels.push(date);
  chart.data.datasets[0].data.push(moodScore);
  chart.update();
}
